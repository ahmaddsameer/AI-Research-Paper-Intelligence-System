# AI-Powered Research Paper Discovery System

An NLP-based research discovery system that searches research papers using the semantic meaning of both **titles and abstracts**, instead of relying only on exact title matches.

The system combines dense semantic retrieval with keyword evidence and enriches the retrieved papers using Named Entity Recognition, keyphrase extraction, abstractive summarization, and explainable relevance information.

## Project Pipeline

`Research Query → SentenceTransformer → FAISS Semantic Retrieval → Hybrid Ranking → NER → KeyBERT → BART Summarization → Relevance Explanation`

## Features

- Searches research papers using title and abstract content
- Generates semantic embeddings with Sentence Transformers
- Uses FAISS for efficient vector similarity search
- Combines semantic similarity and keyword matching through hybrid ranking
- Extracts named entities from paper abstracts
- Extracts important research keyphrases using KeyBERT
- Generates concise abstractive summaries using BART
- Explains why a retrieved paper is relevant to the user query
- Uses saved embeddings and a saved FAISS index to avoid repeated embedding generation

## Technologies Used

- Python
- Pandas
- NumPy
- Sentence Transformers
- FAISS
- Hugging Face Transformers
- KeyBERT
- BART
- BERT-based Named Entity Recognition
- Google Colab
- Google Drive

## Models

- `sentence-transformers/all-MiniLM-L6-v2` — semantic embeddings
- `dslim/bert-base-NER` — Named Entity Recognition
- `facebook/bart-large-cnn` — abstractive summarization

## Search Strategy

### Semantic Search

The title and abstract of each paper are combined into a single text representation. Sentence embeddings capture the semantic meaning of this text. FAISS performs efficient similarity search between the user query embedding and paper embeddings.

### Keyword Search

A keyword score measures direct lexical overlap between the query and each candidate paper.

### Hybrid Ranking

The final ranking combines semantic and keyword evidence:

`Hybrid Score = 0.8 × Semantic Score + 0.2 × Keyword Score`

This allows the system to use both conceptual similarity and exact query-term evidence.

## Post-Retrieval NLP Analysis

After retrieving the highest-ranked papers, the system performs:

- **NER:** extracts named entities from abstracts
- **KeyBERT:** identifies important keyphrases
- **BART:** generates concise paper summaries
- **Relevance Explanation:** reports semantic similarity, matching query terms, and important paper topics

## Example Query

```python
research_paper_search(
    "Deep learning in medical imaging",
    k=3
)
```

For every retrieved paper, the system displays:

- Rank
- Paper title
- Semantic score
- Keyword score
- Hybrid score
- Relevance explanation
- AI-generated summary
- Named entities
- Important keyphrases

## Precomputed FAISS Assets

The notebook uses precomputed embeddings and a FAISS index so that embeddings do not need to be regenerated on every Colab session.

Create the following Google Drive folder:

```text
MyDrive/
└── ML_INTERN_P2/
    ├── paper_embeddings.npy
    └── paper_faiss.index
```

These large precomputed assets are intentionally not included in the repository.

## How to Run

1. Open `Research_Paper_Discovery.ipynb` in Google Colab.
2. Install the required libraries using the notebook setup cells.
3. Add the precomputed embedding and FAISS files to the Google Drive folder shown above.
4. Mount Google Drive when prompted.
5. Run all notebook cells.
6. Test the final pipeline with your own research query.

## Project Motivation

Traditional title-based search can miss relevant papers when researchers use different terminology for similar ideas. This project uses semantic representations of titles and abstracts to retrieve conceptually related papers and then provides NLP-based analysis to make the results easier to understand and evaluate.

## Future Scope

- FastAPI backend for serving the search pipeline as an API
- Web-based research discovery interface
- Domain-specific scientific or biomedical NER
- Larger research paper collections
- Advanced reranking models

## Author

**Vriti Goyal**

Engineering student exploring Machine Learning, NLP, and AI-based research systems.
